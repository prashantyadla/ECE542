
% current_dir = strcat(pwd)
% disp(current_dir)

% temp = dir(current_dir)
% for i = 1:length(temp)
%     val = temp(i).name
%     if val[1] ~= '.'
%         temp_str = strcat(val,"/")
%         image_list = dir(strcat(current_dir,val))
%         for j = 1:length(image_list)
%             image_name = image_list(j).name
%         end
%     end
% end

% for c=1:11
%     leafdata{1,1}{c,1}
% end


% collardata 

leafdata = [];
collardata = data.gTruth.LabelData.collar
for c=1:4
    for x=1:2
        for y=1:2
            leafdata = [leafdata; collardata{1,1}{c,1}(x,y)];
        end
    end
end

s = struct("keypoints", leafdata)
disp(jsonencode(s))


% collardata
collardata = [];
collardata = data.gTruth.LabelData.collar
for c=1:4
    for x=1:2
        for y=1:2
            leafdata = [leafdata; collardata{1,1}{c,1}(x,y)];
        end
    end
end

